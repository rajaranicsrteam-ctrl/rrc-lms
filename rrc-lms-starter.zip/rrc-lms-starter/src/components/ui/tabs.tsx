
import * as React from 'react';
import { cn } from './utils';
type TabsProps = { value: string; onValueChange?: (v:string)=>void; children: any };
export function Tabs({ value, onValueChange, children }: TabsProps){ return <div data-value={value}>{children}</div> }
export function TabsList({ className, ...p }: any){ return <div className={cn('inline-flex rounded-xl bg-gray-100 p-1', className)} {...p}/> }
export function TabsTrigger({ value, children }: any){ return <button className="px-3 py-1 rounded-lg text-sm" onClick={()=>{ const ev = new CustomEvent('tabs-change',{detail:value}); window.dispatchEvent(ev); }}>{children}</button> }
