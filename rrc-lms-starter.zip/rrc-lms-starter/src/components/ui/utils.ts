
export function cn(...a: (string|undefined|null|false)[]){ return a.filter(Boolean).join(' ') }
