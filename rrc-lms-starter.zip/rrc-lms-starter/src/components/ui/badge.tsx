
import * as React from 'react';
import { cn } from './utils';
type Props = React.HTMLAttributes<HTMLSpanElement> & { variant?: 'secondary' };
export function Badge({ className, ...p }: Props){ return <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-gray-100 border border-gray-200', className)} {...p}/> }
