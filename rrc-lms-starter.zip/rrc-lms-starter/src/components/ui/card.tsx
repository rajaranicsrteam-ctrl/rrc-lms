
import * as React from 'react';
import { cn } from './utils';
export function Card({ className, ...p }: any){ return <div className={cn('rounded-2xl border bg-white', className)} {...p}/> }
export function CardHeader({ className, ...p }: any){ return <div className={cn('px-4 py-3 border-b bg-white/60', className)} {...p}/> }
export function CardTitle({ className, ...p }: any){ return <div className={cn('text-base font-semibold', className)} {...p}/> }
export function CardContent({ className, ...p }: any){ return <div className={cn('p-4', className)} {...p}/> }
