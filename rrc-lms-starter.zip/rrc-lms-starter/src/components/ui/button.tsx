
import * as React from 'react';
import { cn } from './utils';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'outline' | 'secondary' | 'ghost' };
export const Button = React.forwardRef<HTMLButtonElement, Props>(function Button({ className, variant, ...props }, ref) {
  const base = 'inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-medium transition border';
  const styles = variant === 'outline' ? 'bg-white border-gray-300 hover:bg-gray-50'
    : variant === 'secondary' ? 'bg-gray-100 border-gray-200'
    : variant === 'ghost' ? 'border-transparent hover:bg-gray-100'
    : 'bg-gray-900 text-white border-transparent hover:opacity-90';
  return <button ref={ref} className={cn(base, styles, className)} {...props} />;
});
export default Button;
