
import * as React from 'react';
import { cn } from './utils';
type Props = React.InputHTMLAttributes<HTMLInputElement>;
export const Input = React.forwardRef<HTMLInputElement, Props>(function Input({ className, ...p }, ref){
  return <input ref={ref} className={cn('h-9 w-full rounded-lg border border-gray-300 px-3 text-sm outline-none focus:ring-2 focus:ring-gray-300', className)} {...p}/>;
});
