
import * as React from 'react';
export function Avatar({ children }: any){ return <div className="h-9 w-9 rounded-full bg-gray-200 flex items-center justify-center">{children}</div> }
export function AvatarFallback({ children }: any){ return <span className="text-sm font-medium">{children}</span> }
