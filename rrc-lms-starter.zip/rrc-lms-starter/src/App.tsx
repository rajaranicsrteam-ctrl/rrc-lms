
import RajaraniLMSPreview from "@/components/RajaraniLMSPreview";

export default function App() {
  (window as any).RAJARANI_LOGO_URL = "/logo.png";
  return <RajaraniLMSPreview />;
}
